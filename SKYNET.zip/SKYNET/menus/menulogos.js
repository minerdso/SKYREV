const menulogos = (prefix) => {
  
// NÃO APAGUE ESSE ${prefix}, não coloque nada ${dentro assim} ISSO SÃO DEFINIÇÕES QUE ESTÁ PUXANDO DO settings.json, da pasta dono, só pode altera a base de tudo, menos as definições, só se quiser apagar a definição completa.  
  
  return `​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​
╭───────────────
╎
╎⎙  Plaquinhas 
╎
╰───────────────
╎
╎⩺ ${prefix}Plaq
╎⩺ ${prefix}Plaq2
╎⩺ ${prefix}Plaq3
╎⩺ ${prefix}Plaq4
╎⩺ ${prefix}Plaq5
╎
╰───────────────

╭───────────────
╎
╎⎙  Logos De 2 Texto
╎
╰───────────────
╎
╎⩺ ${prefix}Comporn (txt/txt) 
╎⩺ ${prefix}Glitch (txt/txt)
╎⩺ ${prefix}Glitch3 (txt/txt)
╎⩺ ${prefix}Grafity (txt-txt)
╎⩺ ${prefix}Space (txt/txt)
╎⩺ ${prefix}Marvel (txt/txt)
╎⩺ ${prefix}GamePlay (txt/txt)
╎⩺ ${prefix}Stone (txt/txt)
╎⩺ ${prefix}Steel (txt/txt)
╎⩺ ${prefix}Ffbanner (txt/txt) 
╎⩺ ${prefix}Mascoteavatar (txt/txt) 
╎
╰───────────────

╭───────────────
╎
╎⎙  Logos De 1 Texto
╎
╰───────────────
╎
╎⩺ ${prefix}Txtquadrinhos (txt) 
╎⩺ ${prefix}HackNeon (txt) 
╎⩺ ${prefix}EquipeMascote (txt) 
╎⩺ ${prefix}FFavatar (txt) 
╎⩺ ${prefix}Gizquadro (txt) 
╎⩺ ${prefix}Angelglx (txt) 
╎⩺ ${prefix}WingEffect (txt) 
╎⩺ ${prefix}Angelwing (txt) 
╎⩺ ${prefix}Blackpink (txt) 
╎⩺ ${prefix}Girlmascote (txt) 
╎⩺ ${prefix}Mascotegame (txt) 
╎⩺ ${prefix}Fpsmascote (txt) 
╎⩺ ${prefix}Logogame (txt) 
╎⩺ ${prefix}Glitch2 (txt) 
╎⩺ ${prefix}3DGold (txt)
╎⩺ ${prefix}Placaloli (txt)
╎⩺ ${prefix}Phadow (txt)
╎⩺ ${prefix}Efeitoneon (txt)
╎⩺ ${prefix}Cemiterio (txt)
╎⩺ ${prefix}Metalgold (txt)
╎⩺ ${prefix}Narutologo (txt)
╎⩺ ${prefix}Fire (txt)
╎⩺ ${prefix}Romantic (txt)
╎⩺ ${prefix}Smoke (txt)
╎⩺ ${prefix}Papel (txt)
╎⩺ ${prefix}Lovemsg (txt)
╎⩺ ${prefix}Lovemsg2 (txt)
╎⩺ ${prefix}Lovemsg3 (txt)
╎⩺ ${prefix}Coffecup (txt)
╎⩺ ${prefix}Coffecup2 (txt)
╎⩺ ${prefix}Cup (txt)
╎⩺ ${prefix}Florwooden (txt)
╎⩺ ${prefix}Lobometal (txt)
╎⩺ ${prefix}Harryp (txt)
╎⩺ ${prefix}Txtborboleta (txt)
╎⩺ ${prefix}Madeira (txt)
╎⩺ ${prefix}Pornhub (txt)
╎⩺ ${prefix}Escudo (txt)
╎⩺ ${prefix}Transformer (txt)
╎⩺ ${prefix}America (txt)
╎⩺ ${prefix}Demongreen (txt)
╎⩺ ${prefix}Wetglass (txt)    
╎⩺ ${prefix}Toxic (txt)     
╎⩺ ${prefix}Neon3 (txt)   
╎⩺ ${prefix}Neondevil (txt) 
╎⩺ ${prefix}Neongreen (txt)
╎⩺ ${prefix}Lava (txt)
╎⩺ ${prefix}Halloween (txt)
╎⩺ ${prefix}Neondevil (txt)
╎⩺ ${prefix}DemonFire (txt)
╎⩺ ${prefix}DemonGreen (txt)
╎⩺ ${prefix}Thunderv2 (txt)
╎⩺ ${prefix}Thunder (txt)
╎⩺ ${prefix}Colaq (txt)
╎⩺ ${prefix}Luxury (txt)
╎⩺ ${prefix}Berry (txt)
╎⩺ ${prefix}Transformer (txt)
╎⩺ ${prefix}Matrix (txt)
╎⩺ ${prefix}Horror (txt)
╎⩺ ${prefix}Nuvem (txt)
╎⩺ ${prefix}Neon (txt)
╎⩺ ${prefix}Neon1 (txt)
╎⩺ ${prefix}Neon2 (txt)
╎⩺ ${prefix}Neon3d (txt)
╎⩺ ${prefix}NeonGreen (txt)
╎⩺ ${prefix}Neon3 (txt)
╎⩺ ${prefix}Neve (txt)
╎⩺ ${prefix}Areia (txt)
╎⩺ ${prefix}Vidro (txt)
╎⩺ ${prefix}Style (txt)
╎⩺ ${prefix}Pink (txt)
╎⩺ ${prefix}Carbon (txt)
╎⩺ ${prefix}Tetalblue (txt)
╎⩺ ${prefix}Toxic (txt)
╎⩺ ${prefix}Jeans (txt)
╎⩺ ${prefix}Ossos (txt)
╎⩺ ${prefix}Asfalto (txt)
╎⩺ ${prefix}Natal (txt)
╎⩺ ${prefix}Joker (txt)
╎⩺ ${prefix}Blood (txt)
╎⩺ ${prefix}Break (txt)
╎⩺ ${prefix}Fiction (txt)
╎⩺ ${prefix}3dstone (txt)
╎⩺ ${prefix}Lapis (txt)
╎⩺ ${prefix}Gelo (txt)
╎⩺ ${prefix}Rainbow (txt)
╎⩺ ${prefix}Metalfire (txt)
╎
╰─────────────╯`
}

exports.menulogos = menulogos

// NÃO APAGUE ESSE ${prefix}, não coloque nada ${dentro assim} ISSO SÃO DEFINIÇÕES QUE ESTÁ PUXANDO DO settings.json, da pasta dono, só pode altera a base de tudo, menos as definições, só se quiser apagar a definição completa. 