const fs = require ('fs')
const { prefix } = JSON.parse(fs.readFileSync('./dono/settings.json'))

module.exports = configMsg = async (conn, body, reply, from, msg) => {
switch(body.toLowerCase()){
       
    
    case "aa":
texto = ` Ok entendi, bom como prefere que eu te explique? 

DIGITE : 

A2 PARA TEXTOS 
A3 PARA AUDIO OU VIDEO
`
conn.sendBT(from, texto, 
"",[
{index: 1, urlButton: {displayText: 'CANAL TELEGRAM', url: 'https://t.me/batmonn'}},
{index: 2, quickReplyButton: {displayText: 'Textos', id: `a2`}},    
{index: 2, quickReplyButton: {displayText: 'Audio/Video', id: `a3`}},  
])
break 

case "bb":
reply(`Ok entendi vamos la!
       
PARA USAR FAVOR PEGAR SEU TESTE ANTES OK TEXTOS ABAIXO PEGUE TESTE   
PARA REVENDER ABAIXA PEGUE OS VALORES
`)
break
case "a2":
reply(`
🚨PARA QUEM  QUER SER REVENDEDOR
 https://youtu.be/orR57-t0NAA⚠️🔺
  40$=10 ACESSOS
  80$=20 ACESSOS
  150$=40 ACESSOS 
 APOS PAGAMENTO VC E COLOCADO EM UM GRUPO DE SUPORTE SÃO MAIS DE 10 PESSOAS Q PODEM TE AUXILIAR EM QUALQUER DÚVIDA APESAR DE SER MTO FÁCIL TODO O PROCESSO.
🚨 COMIGO VC APRENDE A FAZER TRÁFEGO PAGO SO FICA SEM CLIENTES SE FOR PREGUIÇOSO 💸
 # VC PAGA 4 REAIS EM CADA USUÁRIO E VENDE A 10$ OU A 20$ ou 30$ ...

👨🏻‍💻digite a palavra *MENU* para voltar📌

`)
break 

case "a3":
reply(`SIGA OS PASSOS


1️⃣MANDA PRINT DA PARTE Q VC POE USUARIO E SENHA NO APP TELA COMPLETA
2️⃣REINICIA SEU CELULAR
3️⃣LIMPA CACHÊ NO APP E FORCA PARADA
4️⃣ATIVA E DESATIVA O MODO AVIÃO NO SEU CELULAR
5️⃣VERIFIQUE USURIO E SENHA
6️⃣ DIGITE O NUMERO 5 PRE VER VIDEOS DE COMO USAR O APP

👨🏻‍💻digite a palavra *MENU* para voltar📌

`)
break

case "a5":
reply(`

LINK DO VIDEO DE COMO USAR O APP ➡️https://youtu.be/T7JjtIKoMhY

LINK DO VIDEO DE COMO USAR O PAINEL DE REVENDA➡️https://youtu.be/orR57-t0NAA

LINK DO VIDEO DE COMO ATUALIZAR O APP➡️https://youtube.com/shorts/NhFlOkcR0do?feature=share

LINK DO VIDEO DE COMO FORCA PARADA NO APP E LIMPA CACHÊ➡️https://youtu.be/VdZ6YG2WfCc

👨🏻‍💻digite a palavra *MENU* para voltar📌
`)
break 

case "a6":
reply(`Situação Brasil 🇧🇷 

VIVO 🟣 - Funcionando em poucos DDD'S, tem um macete de ir colocando modo avião até achar um IP vulnerável a conexão, tbm tem o método Vivo Easy funcionando em alguns lugares.

TIM 🔵 - Funcionando normalmente, sem nada de anormal.

CLARO 🔴 - Morreu em vários lugares, só está funcionando com planos através das conexões 🔴 SSL 38, 39, 40, 41

OI 🟡 - Do mesmo jeito, funcionando em alguns lugares.

Lembrando que essas quedas não tem nada a ver com o app, as operadoras que simplesmente derrubam, sempre que tiver novidades eu irei avisar aqui, recomendo que fique de olho no nosso canal!")

👨🏻‍💻digite a palavra *MENU* para voltar📌
`)
break 

case "a7":
reply(`TERMO PARA AQUISIÇAO DO SERVIÇO ESTEJA CIENTE
Garantimos Servidores sempre online,  nossas rede vpn é um MÉTODO  para usar Internet ilimitada no chip, se ouver queda das vpn por parte da operadora como as vezes acontece uma ou duas vezes por ano, não fazemos reembolso, se o motivo for por conta de erro do nosso servidor e não conseguimos resolver imediatamente, iremos fazer os estorno do valor descontando os dias usado!

REGRAS PARA USSAR O SERVIÇO

  NUNCA MAIS NUNCA, confie no ehi, isso é um túnel construído entre o computador e seu celular. Tem falhas e tem mistérios envolvidos. Não pode acreditar que é confiável porque não é, é bom pacaraio, mas em 3 anos que uso posso garantir isso te larga na mão. Duas coisas não me deixa confiar nisso: A primeira seria o servidor alugado onde não tenho nenhum controle caiu lá caiu nos tudo. A outra é que usamos a rede das operadoras sem autorização e elas num tão afim de deixar isso barato. Reconectar é basicamente isso a operadora derrubando seu Ip. Reconectar é um sorteio atrás de um ip que ainda não foi bloqueado.
  Não use em seu chip pessoal porque vai achar que a vida é flores e esquecer de colocar credito. Coloque credito mensalmente se for esse o caso.  Vai funcionar o mês todo? Sim e depende! Sim, enquanto aparecer aquela mensagem de rede da vivo quando está sem credito é o convite para entrar na rede, aquilo ali é a porta de entrada. O depende fica por conta do bloqueio total como aconteceu com outras operadoras ou manutenção na rede que acontece por região. 
  Use e abuse, não está roubando ninguém não é crime isso. Pega a visão imagine que você tem internet na sua casa e não quer pagar internet móvel pra que? Você já tem em casa aí você é meio ninja no computador e faz um TUNELAMENTO que manda internet da sua casa pro celular bingo. Ainda não é crime no brasil creio que outro país sim. 
  O uso de tunelamento está ligado ao perfil do freguês. Porque? Exige dele características peculiares como paciência e a persistência. Se não tem, não rouba onda vai colocar credito e viver sua vida feliz, aceite isso não foi feito pra todos.


Como fazer Atendimento ao cliente de internet.

 Pedir print do erro apresentado (pois pelo app ja se dedus)
 Indentificar revenda ou usuario.
 Certificar que login na rede esta aparecendo no cliente, mostrar imagem do mesmo.
 Testa login do mesmo no seu aparelho, revendas tem ter todos chips para poder vender com qualidade.
 Teste sendo positivo, grave um video testando seu acesso. 
 Modo avião até cair o dedo ensinie se for ou caso

Contra fato não há argumentos

Termos e Condições  para Usuário de  VPN .

- Você usa este tipo de app como "alternativa" para ter acesso a conteudos bloqueados na sua rede|internet, o serviço de internet funciona bem,porém é sujeito a vários problemas,como lentidão,quedas e etc,por ser um meio "barato" de conexão,esteja ciente disso ao usar!

- Não somos responsáveis pela rede na qual você acessa nosso serviço,qualquer problema no chip/rede/sinal/wi-fi não é de nossa responsabilidade

 - Problemas de conexão por bloqueio da rede,problemas de sinal e afins

- Você é responsável por manter sua rede no qual faz a conexão ativa

 - Você é responsável por manter seu app/arquivo atualizados para sempre ter melhor funcionamento

 - Reembolso por arrependimento de compra,somente após 1 …

 👨🏻‍💻digite a palavra *MENU* para voltar📌
`)
break 
     
}
}

let file = require.resolve(__filename)
    fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(`Update '${__filename}'`)
	delete require.cache[file]
	require(file)
})